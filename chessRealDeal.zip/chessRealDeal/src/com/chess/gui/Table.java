package com.chess.gui;

import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Tile;
import com.chess.engine.piece.Piece;
import com.chess.engine.player.MoveTransition;
import com.google.common.collect.Lists;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static javax.swing.SwingUtilities.isLeftMouseButton;
import static javax.swing.SwingUtilities.isRightMouseButton;

public class Table {
    private final JFrame gameFrame;
    private final GameHistoryPanel gameHistoryPanel;
    private final TakenPiecesPanel takenPiecesPanel;

    private final BoardPanel boardPanel;
    private Board chessBoard;
    private final MoveLog moveLog;

    public Color lightTileColor = Color.decode("#FFFACD");
    protected   Color darkTileColor = Color.decode("#593E1A");
    public  String pieceIconPath = "art/fancy/";
    //pt click event
    private Tile sourceTile;
    private Tile destinationTile;
    private Piece humanMovedPiece;


    private BoardDirection boardDirection;
    public  boolean highlightLegalMoves = true;
    public  boolean highlightIlegalMoves = true;

    //chesti pt mine
    public int frameNumber = 0;


    private final static Dimension OUTER_FRAME_DIMENSION = new Dimension(600,600);
    private final static Dimension BOARD_PANEL_DIMENSION = new Dimension(400,350);
    private final static Dimension TILE_PANEL_DIMENSION = new Dimension(10,10);




    public Table(){
        this.gameFrame = new JFrame("JChess");
        this.gameFrame.setLayout(new BorderLayout());
        final JMenuBar tableMenuBar = createTableMenuBar();
        this.gameFrame.setJMenuBar(tableMenuBar);
        this.chessBoard = Board.createStandardBoard();
        this.gameHistoryPanel = new GameHistoryPanel();
        this.takenPiecesPanel = new TakenPiecesPanel();
        this.gameFrame.setSize(OUTER_FRAME_DIMENSION);
        this.boardPanel = new BoardPanel();
        this.moveLog = new MoveLog();
        this.boardDirection = BoardDirection.NORMAL;
        this.gameFrame.add(this.takenPiecesPanel,BorderLayout.WEST);
        this.gameFrame.add(this.gameHistoryPanel,BorderLayout.EAST);
        this.gameFrame.add(this.boardPanel, BorderLayout.CENTER);
        this.gameFrame.setVisible(true);

    }

    private JMenuBar createTableMenuBar() {
        final JMenuBar tableMenuBar = new JMenuBar();
        tableMenuBar.add(createFileMenu());
        tableMenuBar.add(createPreferencesMenu());
        tableMenuBar.add(changeBackground());

        return tableMenuBar;
    }

    private JMenu createFileMenu() {
        final JMenu fileMenu = new JMenu("File");


        final JMenuItem openPGN =  new JMenuItem("Load PGN file");

        openPGN.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("open up that PGN file");
            }
        });
        fileMenu.add(openPGN);
        final JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fileMenu.add(exitMenuItem);


        return fileMenu;
    }


    private class BoardPanel extends JPanel{
        final List<TilePanel> boardTiles;


        BoardPanel(){
            super(new GridLayout(8,8));
            this.boardTiles = new ArrayList<>();
            for(int i = 0;i<BoardUtils.NUM_TILES;i++){
                final TilePanel tilePanel = new TilePanel(this,i);//def some parameters here
                this.boardTiles.add(tilePanel);
                add(tilePanel);
            }
            setPreferredSize(BOARD_PANEL_DIMENSION);
            validate();
            }

            public void drawBoard(final Board board){
                removeAll();
        
                System.out.println(frameNumber++);
                for(final TilePanel tilePanel :boardDirection.traverse(boardTiles)){

                        tilePanel.drawTile(board);
                        add(tilePanel);

                }
                this.
                validate();
                repaint();
            }
    }

    public static class MoveLog{
        private final List<Move> moves;

        MoveLog(){

            moves = new ArrayList<>();
        }
        public List<Move> getMoves(){
            return moves;
        }
        public void addMove(final Move move){
            moves.add(move);
        }
        public int size(){
            return moves.size();
        }
        public void clear(){
            this.moves.clear();
        }
        public Move removeMove(int index){
           return this.moves.remove(index);
        }
        public boolean removeMove(final Move move){
            return this.moves.remove(move);
        }
    }







    private class TilePanel extends JPanel {

        private final int tileId;

        TilePanel(final BoardPanel boardPanel,
                  final int tileId) {
            super(new GridBagLayout());
            this.tileId = tileId;
            setPreferredSize(TILE_PANEL_DIMENSION);
            assignTileColour();
            assignTilePieceIcon(chessBoard);
         //   highlightLegalMoves(chessBoard);
          //  highlightIllegalSelfCheckMove(chessBoard);
            addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(final MouseEvent e) {
                    if (isRightMouseButton(e)) {
                        //in caz ca am o piesa selectat cu click dreapta deselectez
                        sourceTile = null;
                        destinationTile = null;
                        humanMovedPiece = null;
                        boardPanel.drawBoard(chessBoard);

                        //testing porpous
                        System.out.println(chessBoard.getTile(tileId).getPiece().isFirstMove());



                    } else if (isLeftMouseButton(e)) {
                        //until if(sourcetile== null) doing dumb shit




                        //selecting a piece
                        if (sourceTile ==null ||chosingAnotherPiece()) {      //  if (sourceTile ==null)
                            //first click
                            sourceTile = chessBoard.getTile(tileId);
                            humanMovedPiece = sourceTile.getPiece();

                            if(humanMovedPiece!=null){
                            if(humanMovedPiece.getPieceAliance()!=chessBoard.currentPlayer().getAliance()){
                                humanMovedPiece =null;
                                sourceTile=null;

                            }}

                            if (humanMovedPiece == null) {
                                sourceTile = null;
                            }
                        } else {//aici se executa mutarea in sine
                            //second click
                            //moving selected piece;
                            destinationTile = chessBoard.getTile(tileId);
                            final Move move = Move.MoveFactory.CreateMove(chessBoard, sourceTile.getTileCoordinate(), destinationTile.getTileCoordinate());
                            final MoveTransition transition = chessBoard.currentPlayer().makeMove(move);

                            if (transition.getMoveStatus().isDone()) {

                                chessBoard = transition.getTransitionBoard();
                                moveLog.addMove(move);

                            }   sourceTile = null;
                                destinationTile = null;
                                humanMovedPiece = null;



                        }
                        SwingUtilities.invokeLater(new Runnable() {//after every clcik do this
                            @Override
                            public void run() {
                                gameHistoryPanel.redo(chessBoard,moveLog);
                                takenPiecesPanel.redo(moveLog);
                                boardPanel.drawBoard(chessBoard);

                            }
                        });
                    }
                }


                public boolean chosingAnotherPiece(){
                    if(chessBoard.getTile(tileId).isTileOccupied()){
                        if(chessBoard.getTile(tileId).getPiece().getPieceAliance()==chessBoard.currentPlayer().getAliance()){
                            return true;
                        }
                    }
                    return false;
                }

                @Override
                public void mousePressed(final MouseEvent e) {

                }

                @Override
                public void mouseReleased(final MouseEvent e) {

                }

                @Override
                public void mouseEntered(final MouseEvent e) {

                }

                @Override
                public void mouseExited(final MouseEvent e) {

                }
            });
            validate();


        }
        public void drawTile(final Board board){
            assignTileColour();
            assignTilePieceIcon(board);
            highlightLegalMoves(board);
            highlightIllegalSelfCheckMove(board);
            validate();
            repaint();
        }

        private void assignTilePieceIcon(final Board board) {
            this.removeAll();
            if(board.getPiece(this.tileId) != null) {
                try{
                    final BufferedImage image = ImageIO.read(new File(pieceIconPath +
                            board.getPiece(this.tileId).getPieceAliance().toString()+ "" +
                            board.getPiece(this.tileId).toString() +
                            ".gif"));
                    add(new JLabel(new ImageIcon(image)));
                } catch(final IOException e) {
                    e.printStackTrace();
                }
            }
        }
        private void assignTileColour() {
            if(BoardUtils.EIGHT_RANK[this.tileId]||
               BoardUtils.SIXTH_RANK[this.tileId]||
               BoardUtils.FOURTH_RANK[this.tileId]||
               BoardUtils.SECOND_RANK[this.tileId]){
                setBackground(this.tileId %2==0? lightTileColor :darkTileColor);
            }else if(BoardUtils.SEVENTH_RANK[this.tileId]||
                     BoardUtils.FIFTH_RANK[this.tileId]||
                     BoardUtils.THIRD_RANK[this.tileId]||
                     BoardUtils.FIRST_RANK[this.tileId]){
                setBackground(this.tileId %2==0?darkTileColor:lightTileColor);
            }
        }
        private void highlightLegalMoves(final Board board){

            Collection<Move> legalMovesWithTheSamePiece = new ArrayList<>();
            for(Move move:board.currentPlayer().getLegalMoves()){
                if(move.getMovedPiece().equals(humanMovedPiece)) {
                    legalMovesWithTheSamePiece.add(move);
                }
                }


            if(highlightLegalMoves){    //humanPieceLegalMoves(board)
                for(final Move move : legalMovesWithTheSamePiece){
                    MoveTransition transition = chessBoard.currentPlayer().makeMove(move);
                    if(transition.getMoveStatus().isDone()){
                    if(move.getDestinationCoordonate()==this.tileId){
                        try{
                            add(new JLabel(new ImageIcon(ImageIO.read(new File("art/misc/green_dot.png")))));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }}

                }
                // de aici bag prostii pr rocada


            }

        }

        private void highlightIllegalSelfCheckMove(final Board board){
            if(highlightIlegalMoves){      //humanPieceLegalMoves(board)

            for(final Move move: humanPieceLegalMoves(board)) {
                MoveTransition transition = chessBoard.currentPlayer().makeMove(move);
                if (transition.getMoveStatus().leavesPlayerInCheck()) {
                    if (move.getDestinationCoordonate() == this.tileId) {
                        try {
                            add(new JLabel(new ImageIcon(ImageIO.read(new File("art/misc/red_dot.png")))));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            }

        }

        private Collection<Move> humanPieceLegalMoves(final Board board){
            if(humanMovedPiece!=null&& humanMovedPiece.getPieceAliance()== board.currentPlayer().getAliance()){


                return humanMovedPiece.calculateLegalMoves(board);
            }
                return Collections.emptyList();
        }
    }
    private JMenu createPreferencesMenu(){
        final JMenu preferencesMenu = new JMenu("Preferences");
        final JMenuItem flipBoardMenuItem = new JMenuItem("Flip Board");

        flipBoardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boardDirection = boardDirection.opposite();
                boardPanel.drawBoard(chessBoard);
            }
        });
        preferencesMenu.add(flipBoardMenuItem);
        final JMenuItem changeStyleMenuItem = new JMenuItem("change style");
        changeStyleMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pieceIconPath = "art/fancy2/";
                boardPanel.drawBoard(chessBoard);
            }
        });
        preferencesMenu.addSeparator();
        preferencesMenu.add(changeStyleMenuItem);
        preferencesMenu.addSeparator();
        //adding the move highlither obtion
        final JCheckBoxMenuItem legalMovesHighlighterCheckBox = new JCheckBoxMenuItem("highlight LegalMoves",true);
        legalMovesHighlighterCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                highlightLegalMoves = legalMovesHighlighterCheckBox.isSelected();
            }
        });
        preferencesMenu.add(legalMovesHighlighterCheckBox);
        //adding the IllegalMovesIncCHek obtion
        final JCheckBoxMenuItem illegalMovesCasueCheck= new JCheckBoxMenuItem("pottential but Illegal moves",true);
        illegalMovesCasueCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                highlightIlegalMoves = illegalMovesCasueCheck.isSelected();
            }
        });
        preferencesMenu.addSeparator();
        preferencesMenu.add(illegalMovesCasueCheck);

        return preferencesMenu;
    }


    public  enum BoardDirection {
        NORMAL{
            @Override
        List<TilePanel> traverse(final List<TilePanel> boardTiles){
                return boardTiles;
            }
            @Override
            BoardDirection opposite(){
                return BoardDirection.FLIPPED;
            }
            },
        FLIPPED{
            @Override
            List<TilePanel> traverse(final List<TilePanel> boardTiles){
                return Lists.reverse(boardTiles);
            }
            @Override
            BoardDirection opposite(){
                return BoardDirection.NORMAL;
            }
        };


        abstract List<TilePanel> traverse(List<TilePanel> boardTiles);

        abstract BoardDirection opposite();
    }

//Modificari facute pe cont proriu

    private JMenu changeBackground(){

        final JMenu changeBackgroundMenu = new JMenu("Background");
        final JMenuItem setDarkModeBackground = new JMenuItem("Black & white");
        setDarkModeBackground.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lightTileColor = Color.DARK_GRAY;
                darkTileColor = Color.BLACK;
                boardPanel.drawBoard(chessBoard);
            }
        });
        changeBackgroundMenu.add(setDarkModeBackground);


        return changeBackgroundMenu;
    }
}

